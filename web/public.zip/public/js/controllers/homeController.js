angular.module('scarecrow.controllers')
  .controller('HomeCtrl', ['$scope', function ($scope) {

  }]);
